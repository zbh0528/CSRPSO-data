"""Check the packaged recorded outputs; run with Python 3, NumPy and SciPy."""
from pathlib import Path
import csv
import numpy as np
from scipy.io import loadmat

root = Path(__file__).resolve().parent


def read_csv(name):
    with (root / "tables" / name).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def key(row):
    return row["Case"], algorithm_id(row["Algorithm"]), int(row["Run"])


def algorithm_id(label):
    return {"PSO": "BPSO", "RLPS-TLBO": "RLPS_TLBO"}.get(label, label)


def close(x, y):
    np.testing.assert_allclose(x, y, rtol=2e-12, atol=2e-14)


def summary_close(values, expected, sample_sd=False):
    actual = values.std(ddof=1) if sample_sd else values.mean()
    # Existing CSVs use 15 significant digits; SD propagates input rounding.
    scale = max(float(np.max(np.abs(values))), abs(expected), np.finfo(float).tiny)
    decimal_step = 10.0 ** (np.floor(np.log10(scale)) - 14)
    tolerance = 2 * decimal_step + 8 * np.finfo(float).eps * scale
    np.testing.assert_allclose(actual, expected, rtol=0, atol=tolerance)


metrics = {key(r): r for r in read_csv("run_metrics.csv")}
engineering = {key(r): r for r in read_csv("engineering_metrics_runs.csv")}
seen = set()
groups = {}
for file in sorted((root / "data").glob("*.mat")):
    data = loadmat(file, simplify_cells=True)
    wf, turbine = data["inputs"]["wf"], data["inputs"]["turbine"]
    runs = list(np.atleast_1d(data["runs"]))
    assert len(runs) == 180
    for r in runs:
        k = file.stem, str(r["algorithm"]), int(r["run_id"])
        assert k not in seen
        seen.add(k)
        m, e = metrics[k], engineering[k]
        history = np.asarray(r["best_history"]).ravel()
        assert history.size == int(r["eval_count"]) == int(r["max_evals"]) == 15000
        assert np.isfinite(history).all() and (np.diff(history) <= 0).all()
        close(history[-1], r["best_fit"])
        for name, value in {"LCOE": r["best_fit"], "AEP_GWh": r["AEP"] / 1e6,
                            "CapacityFactor": r["CF"], "Seed": r["seed"],
                            "Evaluations": r["eval_count"], "Seconds": r["elapsed_seconds"]}.items():
            close(float(m[name]), value)
        layout = np.asarray(r["best_layout"])
        indices = np.asarray(r["best_indices"], dtype=int).ravel() - 1
        close(layout, wf["candidate_points"][indices])
        assert len(set(indices)) == int(turbine["turbine_num"])
        cable = r["cable"]
        lengths = np.asarray(cable["lengths"]).ravel()
        types = np.asarray(cable["types"], dtype=int).ravel() - 1
        prices = np.asarray(wf["innercable_price"]).ravel()
        costs = lengths * prices[types]
        close(costs.sum(), cable["total_cost"])
        close(float(e["CableCost_MEUR"]), costs.sum() / 1e6)
        close(float(e["CableLength_km"]), lengths.sum() / 1e3)
        close(float(e["AEP_GWh_year"]), r["AEP"] / 1e6)
        for t, area in enumerate(np.asarray(wf["innercable_section_area"], dtype=int).ravel()):
            close(float(e[f"Cable_{area}_mm2_km"]), lengths[types == t].sum() / 1e3)
            close(float(e[f"Cable_{area}_mm2_MEUR"]), costs[types == t].sum() / 1e6)
        groups.setdefault(k[:2], []).append(r)

assert len(seen) == 1440 and seen == set(metrics) == set(engineering)
for group, runs in groups.items():
    assert {int(r["run_id"]) for r in runs} == set(range(1, 31))
for row in read_csv("multimetric_statistics_sweep.csv"):
    group = row["Case"], algorithm_id(row["Algorithm"])
    column = {"lcoe": "LCOE", "aep": "AEP_GWh", "eta": "WakeEfficiency_Percent"}[row["Metric"]]
    values = np.array([float(metrics[(group[0], group[1], i)][column]) for i in range(1, 31)])
    summary_close(values, float(row["Mean"]))
    summary_close(values, float(row["Std"]), sample_sd=True)
for row in read_csv("engineering_metrics.csv"):
    group = row["Case"], algorithm_id(row["Algorithm"])
    for column in row:
        if column.endswith("_Mean"):
            name = column[:-5]
            values = np.array([float(engineering[(group[0], group[1], i)][name]) for i in range(1, 31)])
            summary_close(values, float(row[column]))
            summary_close(values, float(row[name + "_SD"]), sample_sd=True)
for row in read_csv("selected_layouts.csv"):
    group = row["Case"], algorithm_id(row["Algorithm"])
    best = min(groups[group], key=lambda r: (float(r["best_fit"]), int(r["run_id"])))
    assert int(row["Run"]) == int(best["run_id"])
    close(float(row["LCOE"]), best["best_fit"])
print("Verified: 8 cases, 6 algorithms, 30 runs each; 1440 records and histories.")
print("Final metrics, layouts, cable totals, summary means/sample SD and selected runs agree.")
