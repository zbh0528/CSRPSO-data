CSRPSO minimal supporting dataset

Associated manuscript:
Cross-Swarm Recombination Particle Swarm Optimizer for Offshore Wind Farm
Layout and Cable Routing Optimization

This package contains recorded outputs for eight wind-farm cases, six
algorithms and 30 repetitions per case/algorithm (1440 runs). Each run used
30 initial layouts and 15000 complete objective evaluations. The data are
extracted from the recorded experiments without rounding scientific values.

FILES AND MANUSCRIPT MAPPING

data/<case>.mat: one MATLAB v5 compressed MAT file per case. Each contains
inputs.wf, inputs.turbine, and a 1-by-180 struct array named runs. Read with
MATLAB load or Python scipy.io.loadmat(..., simplify_cells=True).

tables/run_metrics.csv: final best-LCOE metrics for every run; supports the
LCOE comparison table, final-LCOE distributions and paired comparisons.
tables/engineering_metrics_runs.csv: AEP and cable metrics of the same
best-LCOE layout in every run.
tables/engineering_metrics.csv: arithmetic means and sample SD over 30 runs;
supports the energy-production and collection-system comparison figure.
tables/selected_layouts.csv: minimum-LCOE run selected separately within each
case/algorithm; supports the optimized-layout figure. DataFile points to its
case MAT file; match Algorithm and Run jointly to runs.algorithm and
runs.run_id to identify the corresponding entry.
tables/multimetric_statistics_sweep.csv: existing LCOE, AEP and wake-efficiency
summaries and paired signed-rank statistics.
tables/multimetric_rank_summary_sweep.csv: existing mean ranks across sites.
tables/friedman_sweep.csv: existing Friedman test summaries.
tables/wtl_sweep.csv: existing CSRPSO win/no-significant-difference/loss counts.
verify_dataset.py: runnable numerical consistency check, using Python 3,
NumPy and SciPy. After extraction: python3 verify_dataset.py

Convergence figure: runs.best_history contains all 15000 best-so-far LCOE
values, beginning with evaluation 1 and including initialization. Group by
case and algorithm; compute the pointwise arithmetic mean and sample SD
(denominator N-1) over 30 runs.
Wind distributions figure: inputs.wf.f_theta_v, theta and velocity contain
the joint probabilities and their axes. Multiply probabilities by 100 for
percent. inputs.wf.layout0 contains the supplied layout used to construct
the displayed site outline; wf.boundary is the optimization-domain boundary.

CASE ORDER AND ALGORITHM LABELS

a China_Zhuhai_Guishan_Hai             Zhuhai-Guishan
b Netherlands_Egmond_aan_Zee          Egmond aan Zee
c China_Shanghai_Lingang              Shanghai-Lingang
d Netherlands_Prinses_Amaliawindpark  Prinses Amalia
e Denmark_Nysted                     Nysted
f UK_Sheringham_Shoal                 Sheringham Shoal
g Denmark_Rodsand_II                  Rodsand II
h UK_London_Array                    London Array

Algorithm identifiers: CSRPSO, SaOFGDE, BPSO, AGPSO, DOLSSA, RLPS_TLBO.
BPSO is displayed as PSO and RLPS_TLBO as RLPS-TLBO in the manuscript.
Run is the repetition number 1--30. Matching repetition numbers within a
case share seeds and initial populations. The case order above gives c in
seed = 20261009 + 100000*c + Run.

RUN FIELDS AND UNITS

algorithm / run_id / seed: algorithm identifier, repetition and random seed.
best_fit: lowest recorded LCOE, EUR/kWh.
AEP: annual energy production of that layout, kWh/year.
CF: capacity factor, dimensionless fraction.
best_history: best-so-far LCOE at every complete evaluation, EUR/kWh.
best_indices: selected candidate indices, using MATLAB 1-based indexing.
best_layout: turbine x/y coordinates in metres, in best_indices order.
Pop0: initial population; each of its 30 rows lists selected candidate indices
using MATLAB 1-based indexing.
eval_count / max_evals: completed evaluations and evaluation budget.
elapsed_seconds: elapsed optimizer time in seconds as defined in the manuscript.
cable.connections: two endpoint indices per edge; 0 denotes the substation,
and 1--M denote rows of best_layout.
cable.lengths: corresponding edge lengths in metres.
cable.types: 1-based indices into wf.innercable_section_area/innercable_price.
cable.total_cost: sum(lengths .* price(types)), EUR, for collection cables.

INPUT METADATA

wf.layout0, candidate_points, boundary, substation: planar x/y coordinates, m.
wf.N_candidate: number of candidate sites.
wf.min_turbine_dis: minimum turbine spacing, m.
wf.theta: wind directions in radians; zero is north, increasing clockwise.
wf.theta_source: supplied direction values in degrees.
wf.velocity: free-stream wind-speed centres, m/s.
wf.f_theta_v: joint occurrence probabilities, direction rows by speed columns;
all entries sum to 1. theta_unit and theta_source_unit state angle units.
wf.surface_roughness / sea_depth / offshore_length: m.
wf.innercable_voltage_kV / exportercable_voltage_kV: kV.
wf.cos_phi: power factor, dimensionless.
wf.turbine_power_MW: rated power, MW.
wf.innercable_section_area / exportercable_section_area: conductor area, mm^2.
wf.innercable_rated_current: A.
wf.innercable_price / exportercable_price: EUR/m.
wf.cable_capacity: maximum supported downstream turbine count by cable type.
turbine.ws: wind-speed points, m/s; turbine.pc: power curve, kW.
turbine.Ct: thrust coefficient curve, dimensionless.
turbine.Pinst: rated turbine power, kW.
turbine.hub_height / rotor_diameter / rotor_radius: m.
turbine.CutIn / CutOut: m/s; turbulence_intensity: dimensionless fraction.
turbine.turbine_num: turbine count.

CSV DEFINITIONS AND INTERPRETATION

LCOE is EUR/kWh. AEP_GWh and AEP_GWh_year are GWh/year (MAT AEP / 1e6).
CapacityFactor is a fraction. WakeEfficiency_Percent and MeanEta_pct are
percent of free-flow annual energy production. Evaluations is a count.
Seconds is optimizer elapsed time. CableCost_MEUR is million EUR;
CableLength_km is km. Cable_<area>_mm2_km and Cable_<area>_mm2_MEUR split
length and cost by conductor cross-section. Collection costs exclude export
cables. OriginalAEP_GWh_year is the existing original-layout AEP reference;
AEP_RatioToOriginal is the run AEP divided by that reference.
CaseIndex follows the case order above; CaseLabel and AlgorithmLabel are
display names. N is the number of runs. Mean / Std / SD are arithmetic mean
and sample SD. No data values have been inferred from figure images.

In statistical CSVs, Metric is lcoe, aep or eta (wake efficiency percent).
PairedN is the number of run pairs; NonzeroPairs excludes numerical zeros.
SignedRankP is the two-sided Wilcoxon signed-rank p-value from the existing
MATLAB tie-adjusted normal-approximation analysis; Wplus/Wminus are signed
rank sums for CSRPSO-minus-baseline differences. SignedRankZ is its normal
statistic; RankDifference is Wplus minus Wminus; PairedMedianDifference is
the median paired difference. ComparisonToCSRPSO '+' denotes a CSRPSO win,
'=' no significant difference, '-' a loss, at Alpha=0.05. '--' and NaN mark
the reference algorithm or non-applicable statistical fields.
MeanRank and R_* rank case-wise means across eight sites (lower is better).
RankSites / Sites count complete site blocks; FriedmanP / P are Friedman
p-values, ChiSquare its statistic, DF its degrees of freedom, and Status its
significance summary. CSRPSO_Win, NoSignificantDifference and CSRPSO_Loss
count outcomes across TestedSites; UnavailableSites counts unavailable tests.

The verification script checks the recorded metrics and their summaries,
15000-point histories, selected layouts and cable arithmetic. It reads the
package without changing its files or rerunning the optimization experiments.
